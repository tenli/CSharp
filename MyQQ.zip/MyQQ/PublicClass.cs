﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyQQ
{
    class PublicClass
    {
        public static int loginID; //记录用户ID
    }
}
