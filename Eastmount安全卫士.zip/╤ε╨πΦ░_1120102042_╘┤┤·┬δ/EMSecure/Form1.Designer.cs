﻿namespace EMSecure
{
    partial class EMSecure
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EMSecure));
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.minButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_mol6 = new System.Windows.Forms.Panel();
            this.panel_mol5 = new System.Windows.Forms.Panel();
            this.panel_mol4 = new System.Windows.Forms.Panel();
            this.panel_mol3 = new System.Windows.Forms.Panel();
            this.panel_mol2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel_mol1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel_mol6.SuspendLayout();
            this.panel_mol5.SuspendLayout();
            this.panel_mol4.SuspendLayout();
            this.panel_mol3.SuspendLayout();
            this.panel_mol2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel_mol1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(0, 115);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 360);
            this.panel2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(11, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 14);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::EMSecure.Properties.Resources.clean_ie;
            this.pictureBox1.Location = new System.Drawing.Point(14, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 48);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = global::EMSecure.Properties.Resources.clean_recycle;
            this.pictureBox3.Location = new System.Drawing.Point(15, 5);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(48, 48);
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::EMSecure.Properties.Resources.clean_u;
            this.pictureBox4.Location = new System.Drawing.Point(17, 7);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(48, 48);
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::EMSecure.Properties.Resources.clean_windows;
            this.pictureBox5.Location = new System.Drawing.Point(11, 8);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(48, 48);
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = global::EMSecure.Properties.Resources.delete_files;
            this.pictureBox6.Location = new System.Drawing.Point(13, 8);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(48, 48);
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = global::EMSecure.Properties.Resources.logo;
            this.pictureBox7.Location = new System.Drawing.Point(636, 35);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(140, 70);
            this.pictureBox7.TabIndex = 7;
            this.pictureBox7.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "清除IE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "清空回收站";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 12);
            this.label5.TabIndex = 11;
            this.label5.Text = "u盘记录";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 12);
            this.label6.TabIndex = 12;
            this.label6.Text = "电脑清理";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 12);
            this.label7.TabIndex = 13;
            this.label7.Text = "文件粉碎";
            // 
            // minButton
            // 
            this.minButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minButton.ForeColor = System.Drawing.Color.Transparent;
            this.minButton.Image = global::EMSecure.Properties.Resources.bt_min;
            this.minButton.Location = new System.Drawing.Point(719, 1);
            this.minButton.Name = "minButton";
            this.minButton.Size = new System.Drawing.Size(40, 20);
            this.minButton.TabIndex = 14;
            this.minButton.UseVisualStyleBackColor = true;
            this.minButton.Click += new System.EventHandler(this.minButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.BackgroundImage = global::EMSecure.Properties.Resources.bt_x;
            this.closeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.closeButton.ForeColor = System.Drawing.Color.Transparent;
            this.closeButton.Location = new System.Drawing.Point(756, 1);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(40, 20);
            this.closeButton.TabIndex = 16;
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.panel_mol6);
            this.panel1.Controls.Add(this.panel_mol5);
            this.panel1.Controls.Add(this.panel_mol4);
            this.panel1.Controls.Add(this.panel_mol3);
            this.panel1.Controls.Add(this.panel_mol2);
            this.panel1.Controls.Add(this.panel_mol1);
            this.panel1.Controls.Add(this.closeButton);
            this.panel1.Controls.Add(this.minButton);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(799, 118);
            this.panel1.TabIndex = 1;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            // 
            // panel_mol6
            // 
            this.panel_mol6.Controls.Add(this.label7);
            this.panel_mol6.Controls.Add(this.pictureBox6);
            this.panel_mol6.Location = new System.Drawing.Point(414, 30);
            this.panel_mol6.Name = "panel_mol6";
            this.panel_mol6.Size = new System.Drawing.Size(76, 85);
            this.panel_mol6.TabIndex = 22;
            this.panel_mol6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_mol6_MouseDown);
            // 
            // panel_mol5
            // 
            this.panel_mol5.Controls.Add(this.label6);
            this.panel_mol5.Controls.Add(this.pictureBox5);
            this.panel_mol5.Location = new System.Drawing.Point(331, 30);
            this.panel_mol5.Name = "panel_mol5";
            this.panel_mol5.Size = new System.Drawing.Size(74, 85);
            this.panel_mol5.TabIndex = 21;
            this.panel_mol5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_mol5_MouseDown);
            // 
            // panel_mol4
            // 
            this.panel_mol4.Controls.Add(this.label5);
            this.panel_mol4.Controls.Add(this.pictureBox4);
            this.panel_mol4.Location = new System.Drawing.Point(243, 30);
            this.panel_mol4.Name = "panel_mol4";
            this.panel_mol4.Size = new System.Drawing.Size(81, 85);
            this.panel_mol4.TabIndex = 20;
            this.panel_mol4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_mol4_MouseDown);
            // 
            // panel_mol3
            // 
            this.panel_mol3.Controls.Add(this.label4);
            this.panel_mol3.Controls.Add(this.pictureBox3);
            this.panel_mol3.Location = new System.Drawing.Point(162, 30);
            this.panel_mol3.Name = "panel_mol3";
            this.panel_mol3.Size = new System.Drawing.Size(78, 85);
            this.panel_mol3.TabIndex = 19;
            this.panel_mol3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_mol3_MouseDown);
            // 
            // panel_mol2
            // 
            this.panel_mol2.Controls.Add(this.label3);
            this.panel_mol2.Controls.Add(this.pictureBox2);
            this.panel_mol2.Location = new System.Drawing.Point(83, 30);
            this.panel_mol2.Name = "panel_mol2";
            this.panel_mol2.Size = new System.Drawing.Size(74, 85);
            this.panel_mol2.TabIndex = 18;
            this.panel_mol2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_mol2_MouseDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 9;
            this.label3.Text = "清除word";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::EMSecure.Properties.Resources.clean_office;
            this.pictureBox2.Location = new System.Drawing.Point(11, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(48, 48);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // panel_mol1
            // 
            this.panel_mol1.Controls.Add(this.label2);
            this.panel_mol1.Controls.Add(this.pictureBox1);
            this.panel_mol1.Location = new System.Drawing.Point(8, 30);
            this.panel_mol1.Name = "panel_mol1";
            this.panel_mol1.Size = new System.Drawing.Size(72, 85);
            this.panel_mol1.TabIndex = 17;
            this.panel_mol1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_mol1_MouseDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(567, 488);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(209, 12);
            this.label8.TabIndex = 3;
            this.label8.Text = "By:北京理工大学 软件学院 杨秀璋";
            // 
            // EMSecure
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.BackgroundImage = global::EMSecure.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 509);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EMSecure";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Eastmount安全软件";
            this.Load += new System.EventHandler(this.EMSecure_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.EMSecure_MouseDown);
            this.MouseEnter += new System.EventHandler(this.EMSecure_MouseEnter);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel_mol6.ResumeLayout(false);
            this.panel_mol6.PerformLayout();
            this.panel_mol5.ResumeLayout(false);
            this.panel_mol5.PerformLayout();
            this.panel_mol4.ResumeLayout(false);
            this.panel_mol4.PerformLayout();
            this.panel_mol3.ResumeLayout(false);
            this.panel_mol3.PerformLayout();
            this.panel_mol2.ResumeLayout(false);
            this.panel_mol2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel_mol1.ResumeLayout(false);
            this.panel_mol1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button minButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel_mol6;
        private System.Windows.Forms.Panel panel_mol5;
        private System.Windows.Forms.Panel panel_mol4;
        private System.Windows.Forms.Panel panel_mol3;
        private System.Windows.Forms.Panel panel_mol2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel_mol1;
        private System.Windows.Forms.Label label8;

    }
}

